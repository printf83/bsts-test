"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_printf83_bsts_test"] = self["webpackChunk_printf83_bsts_test"] || []).push([["lib_docs_layout_utilities_js"],{

/***/ "./lib/docs/layout/utilities.js":
/*!**************************************!*\
  !*** ./lib/docs/layout/utilities.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"utilities\": () => (/* binding */ utilities)\n/* harmony export */ });\n/* harmony import */ var _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../ctl/example/_index.js */ \"./lib/ctl/example/_index.js\");\n\nconst utilities = {\n    title: \"Utilities for layout\",\n    description: \"For faster mobile-friendly and responsive development, Bootstrap includes dozens of utility classes for showing, hiding, aligning, and spacing content.\",\n    item: [\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.title(\"Changing {{display}}\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"Use Bootstrap {{nav:docs/utilities/display::display utilities}} for responsively toggling common values of the {{display}} property. Mix it with Bootstrap grid system, content, or components to show or hide them across specific viewports.\"),\n        //-----------------------\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.title(\"Flexbox options\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"Bootstrap is built with flexbox, but not every element’s {{display}} has been changed to {{display: flex}} as this would add many unnecessary overrides and unexpectedly change key browser behaviors. Most of {{nav:docs/components/alert::Bootstrap components}} are built with flexbox enabled.\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"Should you need to add {{display: flex}} to an element, do so with {{.d-flex}} or one of the responsive variants (e.g., {{.d-sm-flex}}). You’ll need this class or {{display}} value to allow the use of Bootstrap extra {{nav:docs/utilities/flex::flexbox utilities}} for sizing, alignment, spacing, and more.\"),\n        //-----------------------\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.title(\"Margin and padding\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"Use the {{margin}} and {{padding}} {{nav:docs/utilities/spacing::spacing utilities}} to control how elements and components are spaced and sized. Bootstrap includes a six-level scale for spacing utilities, based on a {{1rem}} value default {{$spacer}} variable. Choose values for all viewports (e.g., {{.me-3}} for {{margin-right: 1rem}} in LTR), or pick responsive variants to target specific viewports (e.g., {{.me-md-3}} for {{margin-right: 1rem}} —in LTR— starting at the {{md}} breakpoint).\"),\n        //-----------------------\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.title(\"Toggle visibility\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"When toggling {{display}} isn’t needed, you can toggle the {{visibility}} of an element with Bootstrap {{nav:docs/utilities/visibility::visibility utilities}}. Invisible elements will still affect the layout of the page, but are visually hidden from visitors.\"),\n    ],\n};\n\n\n//# sourceURL=webpack://@printf83/bsts-test/./lib/docs/layout/utilities.js?");

/***/ })

}]);