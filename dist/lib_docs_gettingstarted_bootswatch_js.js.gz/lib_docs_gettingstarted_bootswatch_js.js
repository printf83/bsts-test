"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_printf83_bsts_test"] = self["webpackChunk_printf83_bsts_test"] || []).push([["lib_docs_gettingstarted_bootswatch_js"],{

/***/ "./lib/docs/gettingstarted/bootswatch.js":
/*!***********************************************!*\
  !*** ./lib/docs/gettingstarted/bootswatch.js ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   bootswatch: () => (/* binding */ bootswatch)\n/* harmony export */ });\n/* harmony import */ var _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../ctl/example/_index.js */ \"./lib/ctl/example/_index.js\");\n\nconst bootswatch = {\n    title: \"\",\n    description: \"\",\n    item: [\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.title(\"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.ul({\n            item: [\n                \"aaaaaaaaaaaaaaaaaaaaaaaa\",\n                \"aaaaaaaaaaaaaaaaaaaaaaaa\",\n                \"aaaaaaaaaaaaaaaaaaaaaaaa\",\n                \"aaaaaaaaaaaaaaaaaaaaaaaa\",\n            ],\n        }),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.alert({ color: \"info\", callout: true }, \"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.code({\n            output: () => {\n                return [];\n            },\n        }),\n        //-----------------------\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.title(\"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.code({\n            output: () => {\n                return [];\n            },\n        }),\n        //-----------------------\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.subtitle(\"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.codepreview({\n            type: \"css\",\n            code: `\n\t\t\t\t`,\n        }),\n        //-----------------------\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.title(\"CSS\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"\"),\n        //-----------------------\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.subtitle(\"Sass variables\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.text(\"\"),\n        new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_0__.codepreview({\n            type: \"css\",\n            title: \"scss/_variables.scss\",\n            source: \"https://github.com/twbs/bootstrap/blob/v5.3.0/scss/_variables.scss\",\n            code: `\n\t\t\t`,\n        }),\n    ],\n};\n\n\n//# sourceURL=webpack://@printf83/bsts-test/./lib/docs/gettingstarted/bootswatch.js?");

/***/ })

}]);