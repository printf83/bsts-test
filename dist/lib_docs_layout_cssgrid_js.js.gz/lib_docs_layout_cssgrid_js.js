"use strict";
/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_printf83_bsts_test"] = self["webpackChunk_printf83_bsts_test"] || []).push([["lib_docs_layout_cssgrid_js"],{

/***/ "./lib/docs/layout/cssgrid.js":
/*!************************************!*\
  !*** ./lib/docs/layout/cssgrid.js ***!
  \************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   cssgrid: () => (/* binding */ cssgrid)\n/* harmony export */ });\n/* harmony import */ var _printf83_bsts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @printf83/bsts */ \"../bsts/lib/index.js\");\n/* harmony import */ var _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../ctl/example/_index.js */ \"./lib/ctl/example/_index.js\");\n\n\nconst cssgrid = {\n    title: \"CSS Grid\",\n    description: \"Learn how to enable, use, and customize Bootstrap alternate layout system built on CSS Grid with examples and code snippets.\",\n    item: () => {\n        return [\n            new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_1__.section([\n                new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_1__.text(\"Bootstrap’s default grid system represents the culmination of over a decade of CSS layout techniques, tried and tested by millions of people. But, it was also created without many of the modern CSS features and techniques Bootstrap’re seeing in browsers like the new CSS Grid.\"),\n                new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_1__.alert({ color: \"warning\", callout: true }, \"{{b::Heads up—Bootstrap CSS Grid system is experimental and opt-in as of v5.1.0!}} Bootstrap included it in Bootstrap documentation’s CSS to demonstrate it for you, but it’s disabled by default. Keep reading to learn how to enable it in your projects.\"),\n                new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_1__.alert({ color: \"danger\", callout: true }, [\n                    new _printf83_bsts__WEBPACK_IMPORTED_MODULE_0__.b.alert.header(5, \"Unsuppoterd in {{bsts}}\"),\n                    \"This feature will supported when Bootstrap make it opt-in by default or available in CDN.\",\n                ]),\n                new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_1__.text(\"If you like to use this feature using {{bsts}}, you can manually set it by class property:\"),\n                new _ctl_example_index_js__WEBPACK_IMPORTED_MODULE_1__.code({\n                    output: () => {\n                        return new _printf83_bsts__WEBPACK_IMPORTED_MODULE_0__.h.div({ class: \"grid\", textAlign: \"center\" }, [\n                            new _printf83_bsts__WEBPACK_IMPORTED_MODULE_0__.h.div({ class: \"g-col-4\" }, \".g-col-4\"),\n                            new _printf83_bsts__WEBPACK_IMPORTED_MODULE_0__.h.div({ class: \"g-col-4\" }, \".g-col-4\"),\n                            new _printf83_bsts__WEBPACK_IMPORTED_MODULE_0__.h.div({ class: \"g-col-4\" }, \".g-col-4\"),\n                        ]);\n                    },\n                }),\n            ]),\n        ];\n    },\n};\n\n\n//# sourceURL=webpack://@printf83/bsts-test/./lib/docs/layout/cssgrid.js?");

/***/ })

}]);